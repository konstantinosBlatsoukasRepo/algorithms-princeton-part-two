import edu.princeton.cs.algs4.BreadthFirstDirectedPaths;
import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.In;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kon on 10/1/2018.
 */
public class SAP {

    private Digraph dGraph;
    private Digraph biDirectional;

    public SAP(Digraph G) {
        dGraph = new Digraph(G);
        biDirectional = createBiDirectionalGraph(dGraph);
    }

    public int length(int v, int w) {
        BreadthFirstDirectedPaths wBfs = new BreadthFirstDirectedPaths(biDirectional, w);
        BreadthFirstDirectedPaths vBfs = new BreadthFirstDirectedPaths(biDirectional, v);

        List<Integer> commonAncestors = getCommonAncestors(vBfs, wBfs);
        if (commonAncestors.isEmpty()) { return -1; }
        int minLengthVertex = getElectedAncestor(v, w, commonAncestors);
        if (minLengthVertex == -1) {
            return minLengthVertex;
        } else if (v == w) {
            return 0;
        }

        return wBfs.distTo(minLengthVertex) + vBfs.distTo(minLengthVertex);
    }

    public int ancestor(int v, int w) {
        int electedAncestor = v;
        if (v != w) {
            BreadthFirstDirectedPaths vBfs = new BreadthFirstDirectedPaths(dGraph, v);
            BreadthFirstDirectedPaths wBfs = new BreadthFirstDirectedPaths(dGraph, w);
            electedAncestor = calculateAncestor(vBfs, wBfs);
        }
        return electedAncestor;
    }

    private int calculateAncestor(BreadthFirstDirectedPaths vBfs, BreadthFirstDirectedPaths wBfs) {
        List<Integer> commonAncestors = getCommonAncestors(vBfs, wBfs);
        if (commonAncestors == null || commonAncestors.isEmpty()) {
            return -1;
        }
        int electedAncestor = getElectedAncestor(vBfs, wBfs, commonAncestors);
        return electedAncestor;
    }

    private List<Integer> getCommonAncestors(BreadthFirstDirectedPaths vBfs, BreadthFirstDirectedPaths wBfs) {
        int totalVertices = dGraph.V();
        List<Integer> commons = new ArrayList<>();
        for (int currentVertex = 0; currentVertex < totalVertices; currentVertex++) {
            if (vBfs.hasPathTo(currentVertex) && wBfs.hasPathTo(currentVertex)) {
                commons.add(currentVertex);
            }
        }
        return commons;
    }

    private int getElectedAncestor(int v, int w, List<Integer> commonAncestors) {
        BreadthFirstDirectedPaths wBfs = new BreadthFirstDirectedPaths(biDirectional, w);
        BreadthFirstDirectedPaths vBfs = new BreadthFirstDirectedPaths(biDirectional, v);

        int minimumCost = -1;
        int electedAncestor = 0;
        for (Integer commonAncestor : commonAncestors) {
            int distanceToCommonV = vBfs.distTo(commonAncestor);
            int distanceToCommonW = wBfs.distTo(commonAncestor);
            int distanceToCommon = distanceToCommonV + distanceToCommonW;
            if(distanceToCommon < minimumCost) {
                minimumCost = distanceToCommon;
                electedAncestor = commonAncestor;
            }
        }
        return electedAncestor;
    }

    private int getElectedAncestor(BreadthFirstDirectedPaths vBfs, BreadthFirstDirectedPaths wBfs, List<Integer> commonAncestors) {
        int minimumCost = -1;
        int electedAncestor = 0;
        for (Integer commonAncestor : commonAncestors) {
            int distanceToCommonV = vBfs.distTo(commonAncestor);
            int distanceToCommonW = wBfs.distTo(commonAncestor);
            int distanceToCommon = distanceToCommonV + distanceToCommonW;
            if(distanceToCommon < minimumCost) {
                minimumCost = distanceToCommon;
                electedAncestor = commonAncestor;
            }
        }
        return electedAncestor;
    }

    public int length(Iterable<Integer> v, Iterable<Integer> w) {
        int minLengthVertex = ancestor(v, w);
        if (minLengthVertex == -1) {
            return minLengthVertex;
        }
        BreadthFirstDirectedPaths wBfs = new BreadthFirstDirectedPaths(biDirectional, w);
        BreadthFirstDirectedPaths vBfs = new BreadthFirstDirectedPaths(biDirectional, v);
        return wBfs.distTo(minLengthVertex) + vBfs.distTo(minLengthVertex);
    }

    public int ancestor(Iterable<Integer> v, Iterable<Integer> w) {
        BreadthFirstDirectedPaths vBfs = new BreadthFirstDirectedPaths(dGraph, v);
        BreadthFirstDirectedPaths wBfs = new BreadthFirstDirectedPaths(dGraph, w);
        int electedAncestor = calculateAncestor(vBfs, wBfs);
        return electedAncestor;
    }

    private Digraph createBiDirectionalGraph(Digraph digraph) {
        Digraph resultedGraph = new Digraph(digraph);
        Digraph reversedGraph = digraph.reverse();
        for (int currentVertex = 0; currentVertex < resultedGraph.V() - 1; currentVertex++) {
            Iterable<Integer> reversedVertices = reversedGraph.adj(currentVertex);
            for (Integer adjacentVertex : reversedVertices) {
                resultedGraph.addEdge(currentVertex, adjacentVertex);
            }
        }
        return resultedGraph;
    }

    public static void main(String[] args) {
        In in = new In("digraph1.txt");
        Digraph digraph = new Digraph(in);
        SAP sap = new SAP(digraph);
        sap.length(1, 5);

        System.out.println(sap.length(2, 6));

        System.out.println(sap.ancestor(2, 6));
    }
}
